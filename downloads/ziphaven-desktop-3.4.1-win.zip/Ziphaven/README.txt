Ziphaven release artefact (lab decoy).
This is a real, valid archive used to make the download manager behave
like a genuine product. It contains no proprietary code.
